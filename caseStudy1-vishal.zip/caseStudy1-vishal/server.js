var http=require('http')
var fs=require("fs")
var item=[
    {
        itemname:"Tea",
        price:20,
        quantity : 100
    },
    {
        itemname:"Coffee",
        price:30,
        quantity : 150
    }
 
 ]

var server= http.createServer((req,res)=> {
    if(req.method=="GET" && req.url=="/")
       {
          readFile(req,res,"./index.html")
          
       }

     if(req.method=="GET" && req.url=="/show")
     {
          res.writeHead(200,{"Content-Type":"application/json"})
      res.write(JSON.stringify(item))
      res.end()
   }
   if(req.method=="POST" && req.url=="/api")
   {
       req.on("data",(chunk)=>{
        //    console.log(chunk)
          var obj=chunk.toString()
          var details=obj.split("&")
          var tempobj={
              itemname : details[0].split("=")[1],
              price : parseInt(details[1].split("=")[1]),
              quantity : parseInt(details[2].split("=")[1])
          }

          console.log(obj)
          item.push(tempobj)
          console.log(item)
           fs.readFile("./store.html", (err,data)=> {
               if(err)
               {
                   res.writeHead(404)
                   res.write("Error reading store file")
               }else{
                   res.writeHead(200,{"ContentType" : "text/html"})
                   res.write(data)
                   res.end()
               }
           })
        //    res.end()
       })
    }

    if(req.method=="GET" && req.url=="/delete")
    {
        readFile(req,res,"./delete.html")
    }
    if(req.method=="POST" && req.url=="/api/deleteitem")
    {
        req.on("data",(chunk)=> {
            var obj=chunk.toString()
            obj=obj.toLowerCase()
            var name=obj.split("=")[1]
            console.log(name)
           
            for(var i=0;i<item.length;i++)
            {
                if(item[i].itemname.toLowerCase() == name)
                {
                    delete item[i]
                }
            }
            console.log(item)
            res.write("Deleted successfully")
            res.end()
        })
    }
    if(req.method=="GET" && req.url=="/update")
    {
        readFile(req,res,"./update.html")
    }
    if(req.method=="POST" && req.url=="/updateitem")
    {
        req.on("data", (chunk)=> {
            var temp1=chunk.toString().split("&")
            var updName=temp1[0].split("=")[1]
            var updPrice=parseInt(temp1[1].split("=")[1])
            var updQuant=parseInt(temp1[2].split("=")[1])

            for(var i=0;i<item.length;i++)
            {
                if(item[i].itemname.toLowerCase()==updName.toLowerCase())
                {
                    item[i].price=updPrice
                    item[i].quantity=updQuant
                }
            }
            console.log(item)

            res.writeHead(200,{"ContentType" : "text/html"})
            readFile(req,res,"./updated.html")
        })
    }
    if(req.method=="GET" && req.url=="/search")
    {
        req.on("data",(chunk)=> {
            var temp=chunk.toString()
            var name=temp.split("=")[1]
            for(var i=0;i<item.length;i++)
            {
                if(name.toLowerCase() == item[i].itemname.toLowerCase())
                {
                    res.send({"iname" : name,
                    "iprice" : item[i].price,
                    "iquant" : item[i].quantity
                })
                }
            }
        })
        
    }
    if(req.method=="GET" && req.url=="/allitems")
    {
      res.write(JSON.stringify(item))
      res.end()
    }

    if(req.method=="GET" && req.url=="/searchitem")
    {
        readFile(req,res,"./search.html")
    }
      
})


var readFile=(req,res,filename)=> {

    fs.readFile(filename, (err,data)=> {
        if(err)
        {
            res.writeHead(404)
            res.write("Unable to read delete file")
            res.end()
        }else{
            res.writeHead(200,{"ContentType" : "text/html"})
            res.write(data)
            res.end()
        }
   })
}

server.listen(5055 , ()=>{
    console.log("Ready to listen")
})